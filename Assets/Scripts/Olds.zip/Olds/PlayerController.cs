﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{

    public GameObject player;
    private BoxCollider bc;
    private Rigidbody rg;

    public Camera deathCamera;
    public float deadTime = 5;

    //UI
    public GameObject goldUI;
    public GameObject lifeUI;
    public GameObject mainMessageUI;



    public float speed = 5.0f;

    private bool isJump = false;
    public float jumpHeight = 2f;
    float jumpForce;

    public bool isFire = false;
    public float waitFire = 1f;
    public float bulletSpeed = 20f;
    public GameObject bullet;


    public int hp = 20;
    public int attack = 5;
    public int gold = 0;

    // Start is called before the first frame update
    void Awake()
    {
        jumpForce = Mathf.Sqrt(jumpHeight * -2f * Physics.gravity.y);
        this.bc = GetComponent<BoxCollider>();
        this.rg = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
       
       
        if (this.IsDead()){
           
            if (!this.deathCamera.isActiveAndEnabled)
            {
                this.deathCamera.gameObject.SetActive(true);
                this.mainMessageUI.SetActive(true);
            }
            Debug.Log("test");
            this.deadTime -= Time.deltaTime*60  ;
            this.mainMessageUI.GetComponentInChildren<TextMeshProUGUI>().text = "" + Mathf.Round(this.deadTime);
            

            if (this.deadTime < 0)
            {
                Destroy(this.gameObject);
                SceneManager.LoadScene("InitScene");
            }
        }
        else
        {
            ManageInputMovement();
            Fire();

            this.goldUI.GetComponentInChildren<TextMeshProUGUI>().text = "Gold : " + this.gold;
            this.lifeUI.GetComponentInChildren<TextMeshProUGUI>().text = "HP : " + this.hp;
        }
        
    }

    private void ManageInputMovement()
    {
        Vector2 input = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        input = input.normalized * input.magnitude;
        this.rg.velocity = (transform.forward * input.y + transform.right * input.x) * speed + Vector3.up * this.rg.velocity.y;
        
        if (Input.GetButton("Jump") && this.isJump == false)
        {
            this.isJump = true;
            this.rg.AddForce(new Vector3(0, this.jumpForce, 0),ForceMode.Impulse);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.tag.Equals("Ground"))
        {
            this.isJump = false;
        }else if(collision.gameObject.layer == 10)
        {
            this.mainMessageUI.SetActive(true);
           
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.layer == 10)
        {
            if (Input.GetKey(KeyCode.T) && this.gold >= 10)
            {
                this.attack += 5;
                this.gold -= 10;
            }
            else if (Input.GetKey(KeyCode.H) && this.gold >= 10)
            {
                this.hp += 5;
                this.gold -= 10;
 
            }
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if(collision.gameObject.layer == 10)
        {
            this.mainMessageUI.SetActive(false);
        }
    }

public void Fire()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            GameObject bulletClone = Instantiate(bullet, transform.position, transform.rotation);

            Rigidbody rgBullet = bulletClone.GetComponent<Rigidbody>();
            rgBullet.velocity = transform.forward * bulletSpeed;
            Destroy(bulletClone, 2);
        }
    }

    public bool IsDead()
    {
        return this.hp <= 0;
    }


    #region Shop 

    

    #endregion
}
