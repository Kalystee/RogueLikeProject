﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    [Header("Objects")]
    [SerializeField] GameObject cameraAxis;
    [SerializeField] GameObject cameraObject;
    [SerializeField] LayerMask cameraCollisionMask;

    [Header("Camera Rotation Settings")]
    [SerializeField] float verticalSensibility = 1f;
    [SerializeField] float horizontalSensibility = 1f;
    [SerializeField] float swivelSpeed = 5f;
    [SerializeField] float minimumRotationX = 0f;
    [SerializeField] float maximumRotationX = 85f;
    public bool lockOnForward;

    [Header("Zoom Settings")]
    [SerializeField] float zoomSensibility = 1.5f;
    [SerializeField] float minimumZoom = 0.5f;
    [SerializeField] float maximumZoom = 7.5f;

    [SerializeField] bool invertedYRotation = true;
    
    [Header("Camera Settings")]
    [SerializeField] float cameraAdjustementSpeed = 5f;
    [SerializeField] float verticalOffset = 1.5f;
    [SerializeField] float horizontalOffset = 0.75f;
    [SerializeField] CameraSide cameraSide = CameraSide.RIGHT;
    [SerializeField] KeyCode cameraSideSwitchButton = KeyCode.C;

    private float _rotationX = 0;

    float currentZoom;

    public enum CameraSide
    {
        RIGHT,
        LEFT,
        CENTER
    }

    private void Awake()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        if (cameraAxis == null || cameraObject == null)
        {
            Debug.LogError("An element for 'CameraController' is missing!");
            this.enabled = false;
            return;
        }

        currentZoom = cameraObject.transform.localPosition.z;
        _rotationX = cameraAxis.transform.eulerAngles.x;
    }

    private void Update()
    {
        if(Input.GetKeyDown(cameraSideSwitchButton))
        {
            cameraSide = (cameraSide == CameraSide.RIGHT) ? CameraSide.LEFT : CameraSide.RIGHT;
        }

        //Gestion de la rotation de la caméra
        if (Input.GetKeyDown(KeyCode.P))
            lockOnForward = !lockOnForward;

        if (lockOnForward)
        {
            Quaternion cameraRotation = cameraAxis.transform.localRotation;
            Quaternion targetRotation = Quaternion.Euler(cameraAxis.transform.eulerAngles.x, 0, 0);
            cameraAxis.transform.localRotation = Quaternion.Lerp(cameraRotation, targetRotation, Time.deltaTime * swivelSpeed);
            transform.Rotate(0, Input.GetAxis("Mouse X") * horizontalSensibility, 0);
        }
        else
        {
            cameraAxis.transform.Rotate(0, Input.GetAxis("Mouse X") * horizontalSensibility, 0);
        }

        _rotationX -= Input.GetAxis("Mouse Y") * verticalSensibility;
        _rotationX = Mathf.Clamp(_rotationX, minimumRotationX, maximumRotationX);
        float rotationY = cameraAxis.transform.localEulerAngles.y;
        cameraAxis.transform.localEulerAngles = new Vector3(_rotationX, rotationY, 0);

        //Gestion du zoom
        Vector3 cameraPosition = cameraObject.transform.localPosition;
        currentZoom = Mathf.Clamp(currentZoom + Input.mouseScrollDelta.y, -maximumZoom, -minimumZoom);
        cameraPosition.y = verticalOffset;
        if (cameraSide != CameraSide.CENTER)
        {
            cameraPosition.x = (cameraSide == CameraSide.RIGHT ? 1 : -1) * horizontalOffset;
        }
        else
        {
            cameraPosition.x = 0;
        }

        if (Physics.Raycast(transform.position, (cameraObject.transform.position - transform.position).normalized, out RaycastHit hit, -currentZoom, cameraCollisionMask))
        {
            cameraPosition.z = Mathf.Clamp(-hit.distance + 0.5f, -maximumZoom, -minimumZoom);
        }
        else
        {
            cameraPosition.z = currentZoom;
        }

        cameraObject.transform.localPosition = Vector3.Lerp(cameraObject.transform.localPosition, cameraPosition, Time.deltaTime * cameraAdjustementSpeed);
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(transform.position, (cameraObject.transform.position - transform.position).normalized * -currentZoom);
    }
}
