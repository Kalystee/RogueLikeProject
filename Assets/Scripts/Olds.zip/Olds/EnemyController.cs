﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyController : MonoBehaviour
{
    public Camera cam;
    public NavMeshAgent agent;
    public GameObject player;

    public int hp = 10;
    public int attack = 2;

    public int goldLoot = 10;


    // Update is called once per frame
    void Update()
    {
        /*if (Input.GetMouseButtonDown(1))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                agent.SetDestination(hit.point);
            }
        }*/
        Debug.Log("PV Ennemy : " + this.hp);
        if (this.IsDead()) 
        {
            Destroy(this.gameObject);
            this.player.GetComponent<PlayerController>().gold += goldLoot;
        }
        else
        {
            if (this.player && !this.player.GetComponent<PlayerController>().IsDead())
            {
                agent.SetDestination(player.transform.position);

            }
        
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.transform.tag == "Player")
        {
            PlayerController pc = collision.gameObject.GetComponent<PlayerController>();
            pc.hp -= this.attack;
        }else if(collision.transform.tag == "Bullet")
        {
            this.hp -= 5;
            Destroy(collision.gameObject);
        }
    }

    private void OnCollisionStay(Collision collision)
    {

        if (collision.transform.tag == "Player")
        {
            PlayerController pc = collision.gameObject.GetComponent<PlayerController>();
            pc.hp -= this.attack;
        }
        else if (collision.transform.tag == "Bullet")
        {

            this.hp -= 5;
        }
    }

    public bool IsDead()
    {
        return this.hp <= 0;
    }


}
